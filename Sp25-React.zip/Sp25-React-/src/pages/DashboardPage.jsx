
export default function DashboardPage() {
    return (
        <div>
            <h1>這是 Dashboard Page</h1>
            <p>成功切換頁面！</p>
        </div>
    );
}
