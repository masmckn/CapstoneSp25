
export default function LoginPage() {
    return (
        <div>
            <h1>這是 Login Page</h1>
            <p>Alan 這是測試首頁，成功表示 router 沒問題！</p>
        </div>
    );
}
